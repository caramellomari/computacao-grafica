function setup() {
  createCanvas(400, 350);
  background(255, 230, 100); 
  //rectMode(CENTER);
   //preenchimento da elipse
	noStroke();
  
  fill(28,28,28)
  ellipse(200,190,160,160); //fundo do cabelo
  ellipse(200,110,110,100); //coque do cabelo
  
  fill(255,130,65);
  rect(170, 257, 55, 200); //pescoço
  rect(135, 310, 55, 200); //braço esquerdo
  rect(210, 310, 55, 200); //braço direito
  
  fill(123,104,238);
  rect(160, 290, 80, 200); //blusa
  ellipse(150,310,60,50); //manga esquerda
  ellipse(250,310,60,50); //manga direita
  
  fill(255,130,71);
	ellipse(200,210,130,150); //cabeça
  
  fill(28,28,28);
  ellipse(230,150,100,80); //franja direita
  ellipse(150,160,70,70); //franja esquerda
  ellipse(180,135,70,30); //preenchimento do cabelo
  ellipse(165,212,20,20); //olho esquerdo
  ellipse(235,212,20,20); //olho direito
  rect(195, 242, 10, 3); //nariz
  rect(188, 257, 25, 2); //boca
  
  
  
 
  
  
  
  
  //stroke(28)
  //fill(28,28,28);
  //line(250,250,200,250);
	
  
}
