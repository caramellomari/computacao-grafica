function setup() {
  createCanvas(400, 400);

rectMode(CENTER);
strokeWeight(1); //a largura do contorno

//fill(0,183,0); //preenchimento do quadrado
//stroke(0,111,0); //o contorno do quadrado
//rect(400,400,400,400); //o quadrado que está por trás da eclipse
  
fill(255,255,0); //preenchimento da elipse
stroke(000,1,1); //contorno da elipse
ellipse(200,200,300,300);
  
fill(0,0,0); //preenchimento da elipse
stroke(000,1,1); //contorno da elipse
ellipse(200,255,150,100);

noStroke();
fill(255, 255, 0);
ellipse(200,245,160,100);
  
fill(0,0,0); //preenchimento da elipse
stroke(000,1,1); //contorno da elipse
ellipse(150,160,70,120);
  
fill(0,0,0); //preenchimento da elipse
stroke(000,1,1); //contorno da elipse
ellipse(250,160,70,120);
  
//fill(0);
//noFill();
//stroke(0);  
//arc(200, 280, 100, 60, PI / 50, 2 * PI / 2, OPEN); // 180 degrees
}